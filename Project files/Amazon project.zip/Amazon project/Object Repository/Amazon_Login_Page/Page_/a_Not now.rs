<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Not now</name>
   <tag></tag>
   <elementGuidId>0dc8d0d7-4af7-4410-998f-ec1bc9f13b6a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ap-account-fixup-phone-skip-link</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='ap-account-fixup-phone-skip-link']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>82b3c056-a669-425d-82a2-831e66c1f9b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ap-account-fixup-phone-skip-link</value>
      <webElementGuid>bdd51495-74b9-433a-b769-80961620f4e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-link-normal</value>
      <webElementGuid>b6a117a2-6064-47de-997d-8d4aaf3647b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.amazon.com/ap/signin?openid.pape.max_auth_age=900&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;appActionToken=fYTj2BIPWEkRc2p0YqGGEG6lwVOnQj3D&amp;pageId=usflex&amp;openid.pape.preferred_auth_policies=http%3A%2F%2Fschemas.openid.net%2Fpape%2Fpolicies%2F2007%2F06%2Fnone&amp;openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_signin%26returnFromLogin%3D1&amp;openid.assoc_handle=usflex&amp;partialToken=PT%7C1%7CcRAT5mD9FN3C3By9qLZvf47HW5gZVGh2qiGcIRXpGH3SDMYocV3CrM2+WqabXrTmmIa9pbQUo6zj%2FJOIU5V5U5OBacH3wCH0UAwzoVt65vGJeejqkFr9400SWzffsOpv2K%2Fw9d9QfOYIWcpyRZEB41iEIpUY+mK6hMe4HvB2ndsOhXciKn%2FtSuAP6LnzrQG+8Es2rspo6CSUep3Fk1F+e9NB0puSYza5XqBt5u8Ufa%2FV7ykaXFeNHo3RSWRiyYKd9R%2FBGzgxyRrqjrXkM7wQN58RZRomN0AwJr4hLvEMeePepdx55fukLyJ82msvCEeYZQHIoB3iFIKEAcabnP1Fcw%3D%3D&amp;openid.mode=checkid_setup&amp;appAction=ACCOUNT_FIXUP_PHONE_ADD_COMPLETE&amp;ref_=ap_reachability_skip&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&amp;authenticationPolicy=SinglefactorWithMobileVerification</value>
      <webElementGuid>79d901a2-9a37-49a1-9b00-c11296e430de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                  Not now
                </value>
      <webElementGuid>234cf287-1cd5-4c81-841c-6f75fbcbe98a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ap-account-fixup-phone-skip-link&quot;)</value>
      <webElementGuid>55b2f6dd-32a6-4a95-b5c8-642bd3f7c1d1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@id='ap-account-fixup-phone-skip-link']</value>
      <webElementGuid>84fdf3c8-9d60-4351-90e0-ebcfc3439cc4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='auth-account-fixup-phone-form']/div/div[5]/div/a</value>
      <webElementGuid>6f21ad6c-d783-4ce7-aec7-a7a484922dcc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Not now')]</value>
      <webElementGuid>27d0b964-c919-4999-87dc-e6b7ade2f542</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://www.amazon.com/ap/signin?openid.pape.max_auth_age=900&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;appActionToken=fYTj2BIPWEkRc2p0YqGGEG6lwVOnQj3D&amp;pageId=usflex&amp;openid.pape.preferred_auth_policies=http%3A%2F%2Fschemas.openid.net%2Fpape%2Fpolicies%2F2007%2F06%2Fnone&amp;openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_signin%26returnFromLogin%3D1&amp;openid.assoc_handle=usflex&amp;partialToken=PT%7C1%7CcRAT5mD9FN3C3By9qLZvf47HW5gZVGh2qiGcIRXpGH3SDMYocV3CrM2+WqabXrTmmIa9pbQUo6zj%2FJOIU5V5U5OBacH3wCH0UAwzoVt65vGJeejqkFr9400SWzffsOpv2K%2Fw9d9QfOYIWcpyRZEB41iEIpUY+mK6hMe4HvB2ndsOhXciKn%2FtSuAP6LnzrQG+8Es2rspo6CSUep3Fk1F+e9NB0puSYza5XqBt5u8Ufa%2FV7ykaXFeNHo3RSWRiyYKd9R%2FBGzgxyRrqjrXkM7wQN58RZRomN0AwJr4hLvEMeePepdx55fukLyJ82msvCEeYZQHIoB3iFIKEAcabnP1Fcw%3D%3D&amp;openid.mode=checkid_setup&amp;appAction=ACCOUNT_FIXUP_PHONE_ADD_COMPLETE&amp;ref_=ap_reachability_skip&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&amp;authenticationPolicy=SinglefactorWithMobileVerification')]</value>
      <webElementGuid>31f4b35c-b4b8-49e9-b9a3-10314dfcf1d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/a</value>
      <webElementGuid>c0579ce6-8163-48c1-baa3-6a3d01f510de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@id = 'ap-account-fixup-phone-skip-link' and @href = 'https://www.amazon.com/ap/signin?openid.pape.max_auth_age=900&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;appActionToken=fYTj2BIPWEkRc2p0YqGGEG6lwVOnQj3D&amp;pageId=usflex&amp;openid.pape.preferred_auth_policies=http%3A%2F%2Fschemas.openid.net%2Fpape%2Fpolicies%2F2007%2F06%2Fnone&amp;openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_signin%26returnFromLogin%3D1&amp;openid.assoc_handle=usflex&amp;partialToken=PT%7C1%7CcRAT5mD9FN3C3By9qLZvf47HW5gZVGh2qiGcIRXpGH3SDMYocV3CrM2+WqabXrTmmIa9pbQUo6zj%2FJOIU5V5U5OBacH3wCH0UAwzoVt65vGJeejqkFr9400SWzffsOpv2K%2Fw9d9QfOYIWcpyRZEB41iEIpUY+mK6hMe4HvB2ndsOhXciKn%2FtSuAP6LnzrQG+8Es2rspo6CSUep3Fk1F+e9NB0puSYza5XqBt5u8Ufa%2FV7ykaXFeNHo3RSWRiyYKd9R%2FBGzgxyRrqjrXkM7wQN58RZRomN0AwJr4hLvEMeePepdx55fukLyJ82msvCEeYZQHIoB3iFIKEAcabnP1Fcw%3D%3D&amp;openid.mode=checkid_setup&amp;appAction=ACCOUNT_FIXUP_PHONE_ADD_COMPLETE&amp;ref_=ap_reachability_skip&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&amp;authenticationPolicy=SinglefactorWithMobileVerification' and (text() = '
                  Not now
                ' or . = '
                  Not now
                ')]</value>
      <webElementGuid>1b84aa82-df01-400c-8da6-587d8babe15a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://www.amazon.com/ap/signin?openid.pape.max_auth_age=900&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;appActionToken=SxTvzlcYkbzcVwmgXVDZX7SOmO4j3D&amp;pageId=usflex&amp;openid.pape.preferred_auth_policies=http%3A%2F%2Fschemas.openid.net%2Fpape%2Fpolicies%2F2007%2F06%2Fnone&amp;openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_ya_signin%26returnFromLogin%3D1&amp;openid.assoc_handle=usflex&amp;partialToken=PT%7C1%7CpqVyPUNuoA5DNw84pllLuHcB6z8nzm1REcTvw%2Fi8yIr5HRRYXmWbmirecotpQt3y3RvAYvtC89lw1uR2k9dwhURDXtDE0QnP3zA5bcspVy+oUx8f696jEjHPjjVzfGVdL7uUIdHoO8Qv4Z843tL7YeFP%2FygsBZzz9dVTRJOh83ouUjzaNmYVPbswseNbZ5PYpX2pG0rCfq5rxY1DyCjQ1Th%2FIo2vhAIjGZUkCh2NpjtaStP4vKzCUY8ir9uQnLw0YdUELtrS9cvbEMj4Mfkl+S2J%2FiznVIjf0WsLmmg40duqWlmBsDnehrSOOyA7VEkvSynZH%2FI39mG0T%2F12JAw+laM%3D&amp;openid.mode=checkid_setup&amp;appAction=ACCOUNT_FIXUP_PHONE_ADD_COMPLETE&amp;ref_=ap_reachability_skip&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&amp;authenticationPolicy=SinglefactorWithMobileVerification')]</value>
      <webElementGuid>ab138d0b-61b0-4751-a1a7-37b3a3e928f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@id = 'ap-account-fixup-phone-skip-link' and @href = 'https://www.amazon.com/ap/signin?openid.pape.max_auth_age=900&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;appActionToken=SxTvzlcYkbzcVwmgXVDZX7SOmO4j3D&amp;pageId=usflex&amp;openid.pape.preferred_auth_policies=http%3A%2F%2Fschemas.openid.net%2Fpape%2Fpolicies%2F2007%2F06%2Fnone&amp;openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_ya_signin%26returnFromLogin%3D1&amp;openid.assoc_handle=usflex&amp;partialToken=PT%7C1%7CpqVyPUNuoA5DNw84pllLuHcB6z8nzm1REcTvw%2Fi8yIr5HRRYXmWbmirecotpQt3y3RvAYvtC89lw1uR2k9dwhURDXtDE0QnP3zA5bcspVy+oUx8f696jEjHPjjVzfGVdL7uUIdHoO8Qv4Z843tL7YeFP%2FygsBZzz9dVTRJOh83ouUjzaNmYVPbswseNbZ5PYpX2pG0rCfq5rxY1DyCjQ1Th%2FIo2vhAIjGZUkCh2NpjtaStP4vKzCUY8ir9uQnLw0YdUELtrS9cvbEMj4Mfkl+S2J%2FiznVIjf0WsLmmg40duqWlmBsDnehrSOOyA7VEkvSynZH%2FI39mG0T%2F12JAw+laM%3D&amp;openid.mode=checkid_setup&amp;appAction=ACCOUNT_FIXUP_PHONE_ADD_COMPLETE&amp;ref_=ap_reachability_skip&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&amp;authenticationPolicy=SinglefactorWithMobileVerification' and (text() = '
                  Not now
                ' or . = '
                  Not now
                ')]</value>
      <webElementGuid>5c73595b-ec00-42e3-b827-d46f0e29da79</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
