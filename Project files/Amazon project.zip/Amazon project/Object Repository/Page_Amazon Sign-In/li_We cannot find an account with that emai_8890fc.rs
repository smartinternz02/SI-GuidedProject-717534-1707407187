<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_We cannot find an account with that emai_8890fc</name>
   <tag></tag>
   <elementGuidId>f3c62274-10b7-41a0-94a7-f49c26bdf7f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='auth-error-message-box']/div/div/ul/li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>2bc8c1f5-3f3f-4c87-bcfc-3001788064d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            We cannot find an account with that email address
          </value>
      <webElementGuid>5ab3c720-7481-4822-84e9-38137d0237ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;auth-error-message-box&quot;)/div[@class=&quot;a-box-inner a-alert-container&quot;]/div[@class=&quot;a-alert-content&quot;]/ul[@class=&quot;a-unordered-list a-nostyle a-vertical a-spacing-none&quot;]/li[1]</value>
      <webElementGuid>ccb85814-0184-4791-bac4-19ed24ca0e79</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='auth-error-message-box']/div/div/ul/li</value>
      <webElementGuid>d1277ef4-7a5b-4dcf-b6c3-7243d632abc5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li</value>
      <webElementGuid>7845d1cf-e705-4c7f-b8a0-66ee814c8b94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = '
            We cannot find an account with that email address
          ' or . = '
            We cannot find an account with that email address
          ')]</value>
      <webElementGuid>1192a5ab-dae7-482d-9165-ee45545f39f0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
